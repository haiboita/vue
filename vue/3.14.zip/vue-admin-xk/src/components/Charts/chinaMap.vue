<template>
  <div class="chinaMap" id="chinaMap" style="{height:100%,width:100%}"/>
</template>

<script>
import echarts from 'echarts'
import map from 'echarts/lib/chart/map';
import china from 'echarts/map/js/china.js';

export default {
    
}
</script>
