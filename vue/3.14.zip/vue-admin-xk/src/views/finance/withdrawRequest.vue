<template>
    <h1>提现申请</h1>
</template>

<script>
export default {
  name: 'withdrawRequest'
}
</script>