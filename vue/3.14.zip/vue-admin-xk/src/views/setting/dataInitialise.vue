<template>
    <h1>数据初始化</h1>
</template>
<script>
export default {
  name: 'dataInitialise'
}
</script>