<template>
    <h1>评价列表</h1>
</template>

<script>
export default {
  name: 'appraiseList'
}
</script>