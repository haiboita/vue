<template>
    <h1>友情链接</h1>
</template>

<script>
export default {
  name: 'friendlyLink'
}
</script>