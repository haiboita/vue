<template>
    <h1>运费模板</h1>
</template>

<script>
export default {
  name: 'freightTemplate'
}
</script>