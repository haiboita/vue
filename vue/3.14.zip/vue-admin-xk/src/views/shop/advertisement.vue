<template>
    <h1>广告&排版</h1>
</template>

<script>
export default {
  name: 'advertisement'
}
</script>