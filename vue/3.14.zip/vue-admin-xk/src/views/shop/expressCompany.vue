<template>
    <h1>快递公司</h1>
</template>

<script>
export default {
  name: 'expressCompany'
}
</script>