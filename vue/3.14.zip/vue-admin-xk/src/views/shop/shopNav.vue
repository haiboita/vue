<template>
    <h1>商城导航</h1>
</template>

<script>
export default {
  name: 'shopNav'
}
</script>