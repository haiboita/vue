<template>
    <h1>首页轮播图</h1>
</template>

<script>
export default {
  name: 'banner'
}
</script>