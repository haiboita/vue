<template>
  <xk-member-list :memberType="0"/>
</template>

<script>
import XkMemberList from "./components/XkMemberList";

export default {
  name: "freeMembersList",
  components: { XkMemberList },
  filters: {},
  data() {
    return {};
  },
  methods: {}
};
</script>

<style scoped>
</style>

