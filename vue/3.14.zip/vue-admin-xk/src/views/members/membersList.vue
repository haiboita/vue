<template>
  <xk-member-list :memberType="1"/>
</template>

<script>
import XkMemberList from "./components/XkMemberList";

export default {
  name: "membersList",
  components: { XkMemberList },
  filters: {},
  data() {
    return {};
  },
  methods: {}
};
</script>

<style scoped>
</style>

