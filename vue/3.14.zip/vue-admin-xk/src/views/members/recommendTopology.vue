<template>
    <h1>推荐拓扑</h1>
</template>

<script>
export default {
  name: 'recommendTopology'
}
</script>