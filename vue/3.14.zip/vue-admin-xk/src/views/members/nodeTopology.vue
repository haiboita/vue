<template>
    <h1>节点拓扑</h1>
</template>

<script>
export default {
  name: 'nodeTopology'
}
</script>